package org.myproject.cassandraproject.repository;

import java.util.List;

import org.myproject.cassandraproject.entity.Product;
import org.myproject.cassandraproject.service.HarvesterRequest;
import org.myproject.cassandraproject.service.HarvesterResponse;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepo extends CassandraRepository<Product, Integer> {
	@Query("select * from harvester_platform.harvest_item where primary_request_id =?1 ;")
	 List<Product> getAllProductByPRI(String PRI);
	
	HarvesterResponse getPRIForOneKeyword(HarvesterRequest request);
}
