package org.myproject.cassandraproject.entity;

public class DetailParsedFields {
	String brandOnSite;
	String category;
	String crawTime;
	String detailContentCacheURL;
	String detailItemName;
	String detailPageURL;
	Long itemNumber;
	String landingURL;
	Long phashbinary;
	String proxyCity;
	String proxyCountry;
	String proxyHost;
	String proxyProvider;
	Integer reviewCount;
	Double salePrice;
	String sellerHref;
	String sellerName;
	Integer sellerNameIndex;
	String SKU;
	String thumbnailCacheURL;
	String thumbnailURL;

}
