package org.myproject.cassandraproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

/**
 *  *
 */

@EnableCassandraRepositories
@SpringBootApplication
@PropertySource(name="applicationproperties", value = { "application.properties" })
public class App 
{
    public static void main( String[] args )
    {
//        Properties cassandraProps = new Properties();
//        cassandraProps.put("spring.data.cassandra.keyspace-name", "system");
//        cassandraProps.put("spring.data.cassandra.contact-points", "qa-mesos-private-05.mm-corp.net");
//        cassandraProps.put("spring.data.cassandra.port", "9042");
//        
//        cassandraProps.put("server.port", 8082);
//        

       ConfigurableApplicationContext run = SpringApplication.run(App.class, args);
       
        
        
    }
}
