package org.myproject.cassandraproject.service;

import org.myproject.cassandraproject.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;

public class ProduceServiceImpl implements ProductService {
	@Autowired
	ProductRepo productRepo;
	
	HarvesterResponse response;

	@Override
	public HarvesterResponse getPRIForOneDomainAndOneKeyword(HarvesterRequest request) {

		if(request != null) {
			 
			
			
		}
		response.setMessage("excepton occured, unable to get PRI");
	    response.setStatusCode("000000");
	   
		return response;
	}

}
