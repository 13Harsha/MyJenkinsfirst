package org.myproject.cassandraproject.service;

import org.springframework.stereotype.Service;

@Service
public interface ProductService {

	HarvesterResponse getPRIForOneDomainAndOneKeyword(HarvesterRequest request);
	

}
