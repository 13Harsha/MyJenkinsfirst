package org.myproject.cassandraproject.entity;

public class ListingParsedFields {
	 String nStar;
	 String crawlTime;
	 String currencyCode;
	 String detailPageURL;
	 String itemBrand;
	 String ItemCompany;
	 
}
