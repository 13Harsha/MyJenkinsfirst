package org.myproject.cassandraproject.service;

public class HarvesterRequest {
	
	private String customerId;
	private String keyword;
	private Integer pagesToPaginate;
	private Integer priority;
	private Integer reHarvestIntervalInDays;
	private String referenceId;
	private String requestType;
	private String requesterApplication;
	private String requesterModule;
	private Integer siteId;
	
	public HarvesterRequest(String customerId, String keyword, Integer pagesToPaginate, Integer priority, Integer reHarvestIntervalInDays, 
			String referenceId, String requestType, String requesterApplication, String requesterModule, Integer siteId)	{
		this.customerId = customerId;
		this.keyword = keyword;
		this.pagesToPaginate = pagesToPaginate;
		this.priority = priority;
		this.reHarvestIntervalInDays = reHarvestIntervalInDays;
		this.referenceId = referenceId;
		this.requestType = requestType;
		this.requesterApplication = requesterApplication;
		this.requesterModule = requesterModule;
		this.siteId = siteId;
	}
	
	public HarvesterRequest() {
		
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public Integer getPagesToPaginate() {
		return pagesToPaginate;
	}
	public void setPagesToPaginate(Integer pagesToPaginate) {
		this.pagesToPaginate = pagesToPaginate;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public Integer getReHarvestIntervalInDays() {
		return reHarvestIntervalInDays;
	}
	public void setReHarvestIntervalInDays(Integer reHarvestIntervalInDays) {
		this.reHarvestIntervalInDays = reHarvestIntervalInDays;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getRequesterApplication() {
		return requesterApplication;
	}
	public void setRequesterApplication(String requesterApplication) {
		this.requesterApplication = requesterApplication;
	}
	public String getRequesterModule() {
		return requesterModule;
	}
	public void setRequesterModule(String requesterModule) {
		this.requesterModule = requesterModule;
	}
	public Integer getSiteId() {
		return siteId;
	}
	public void setSiteId(Integer siteId) {
		this.siteId = siteId;
	}
	
	

}
