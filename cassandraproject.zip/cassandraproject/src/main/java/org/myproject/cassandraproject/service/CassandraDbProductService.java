package org.myproject.cassandraproject.service;

import java.util.List;

import org.myproject.cassandraproject.entity.Product;
import org.springframework.stereotype.Service;

@Service
public interface CassandraDbProductService {
	
	List<Product> getProductsByPRI(String PRI);

}
