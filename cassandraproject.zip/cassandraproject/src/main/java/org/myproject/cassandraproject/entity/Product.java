package org.myproject.cassandraproject.entity;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	String primary_request_id;
	
	@Column(name="url")
	String URL;
	
	@Column(name="request_detail")
	String requestDetail;
	
	@Column(name="created_timestamp")
	String createdTimeStamp;
	
	@Column(name="global_item_id")
	String globalItemID;
	
	@Column(name="is_cached")
	Boolean isCached;
	
	@Column(name="page_number")
	Integer pageNumber;
	
	@Column(name="updated_timestamp")	
	String updatedTimeStamp;
	
	@Column(name="updated_user")
	String updatedUser;
	
	@Column(name="detail_parsed_fields")
	Map<String, String> detailParsedFields;
	
	@Column(name="listing_parsed_fields")
	Map<String, String> listingParsedFields;
	
	
	
	
	
	public String getprimary_request_id() {
		return primary_request_id;
	}
	public void setprimary_request_id(String primaryRequestID) {
		this.primary_request_id = primaryRequestID;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	public String getRequestDetail() {
		return requestDetail;
	}
	public void setRequestDetail(String requestDetail) {
		this.requestDetail = requestDetail;
	}
	public String getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	public void setCreatedTimeStamp(String createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	public String getGlobalItemID() {
		return globalItemID;
	}
	public void setGlobalItemID(String globalItemID) {
		this.globalItemID = globalItemID;
	}
	public Boolean getIsCached() {
		return isCached;
	}
	public void setIsCached(Boolean isCached) {
		this.isCached = isCached;
	}
	public Integer getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getUpdatedTimeStamp() {
		return updatedTimeStamp;
	}
	public void setUpdatedTimeStamp(String updatedTimeStamp) {
		this.updatedTimeStamp = updatedTimeStamp;
	}
	public String getUpdatedUser() {
		return updatedUser;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}
	public Map<String, String> getDetailParsedFields() {
		return detailParsedFields;
	}
	public void setDetailParsedFields(Map<String, String> detailParsedFields) {
		this.detailParsedFields = detailParsedFields;
	}
	public Map<String, String> getListingParsedFields() {
		return listingParsedFields;
	}
	public void setListingParsedFields(Map<String, String> listingParsedFields) {
		this.listingParsedFields = listingParsedFields;
	}
	
	
	
	
	

}
