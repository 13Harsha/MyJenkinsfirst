package org.myproject.cassandraproject.service;

import java.util.List;

import org.myproject.cassandraproject.entity.Product;
import org.myproject.cassandraproject.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;

public class CassandraDbProductServiceImpl implements CassandraDbProductService {
	@Autowired
	ProductRepo productRepo;

	@Override
	public List<Product> getProductsByPRI(String PRI) {
		if(PRI != null) {
			List<Product> productList = productRepo.getAllProductByPRI(PRI);
			return productList;
		}
		return null;
	
	}

}
