package com.cassandra.controller;

public class CassandraController {

}
