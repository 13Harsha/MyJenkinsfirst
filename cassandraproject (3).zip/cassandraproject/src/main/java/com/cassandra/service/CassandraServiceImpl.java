package com.cassandra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cassandra.entity.Product;
import com.cassandra.repo.ProductRepo;

public class CassandraServiceImpl implements CassandraService {
	
	@Autowired
	ProductRepo productRepo;

	@Override
	public List<Product> getProductsByPRI(String pri) {
		List<Product> productList = productRepo.getAllProductByPRI(pri);
		return productList;
	}

}
