package com.cassandra.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cassandra.repo.ProductRepo;

public class ProduceServiceImpl implements ProductService {
	@Autowired
	ProductRepo productRepo;
	
	HarvesterResponse response;

	@Override
	public HarvesterResponse getPRIForOneDomainAndOneKeyword(HarvesterRequest request) {

		if(request != null) {
			 
			
			
		}
		response.setMessage("excepton occured, unable to get PRI");
	    response.setStatusCode("000000");
	   
		return response;
	}

}
