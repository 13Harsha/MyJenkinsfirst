package com.cassandra.service;

import org.springframework.stereotype.Component;

@Component
public class HarvesterResponse {
	
	private String message ;
	private String primaryRequestId;
	private Number responseTimeInMs;
	private String secondaryRequestId;
	private String statusCode;
	
	public HarvesterResponse(String message, String primaryRequestId, Number responseTimeInMs, String secondaryRequestId, String statusCode) {
		this.message = message;
		this.primaryRequestId = primaryRequestId;
		this.responseTimeInMs = responseTimeInMs;
		this.secondaryRequestId = secondaryRequestId;
		this.statusCode = statusCode;
	}
	
	public HarvesterResponse(){
		
	}
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getPrimaryRequestId() {
		return primaryRequestId;
	}
	public void setPrimaryRequestId(String primaryRequestId) {
		this.primaryRequestId = primaryRequestId;
	}
	public Number getResponseTimeInMs() {
		return responseTimeInMs;
	}
	public void setResponseTimeInMs(Number responseTimeInMs) {
		this.responseTimeInMs = responseTimeInMs;
	}
	public String getSecondaryRequestId() {
		return secondaryRequestId;
	}
	public void setSecondaryRequestId(String secondaryRequestId) {
		this.secondaryRequestId = secondaryRequestId;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	

}
