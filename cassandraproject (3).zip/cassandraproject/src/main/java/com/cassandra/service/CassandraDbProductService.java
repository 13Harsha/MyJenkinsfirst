package com.cassandra.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cassandra.entity.Product;

@Service
public interface CassandraDbProductService {
	
	List<Product> getProductsByPRI(String PRI);

}
