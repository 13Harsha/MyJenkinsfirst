package com.cassandra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cassandra.entity.Product;
import com.cassandra.repo.ProductRepo;

public class CassandraDbProductServiceImpl implements CassandraDbProductService {
	@Autowired
	ProductRepo productRepo;

	@Override
	public List<Product> getProductsByPRI(String PRI) {
		if(PRI != null) {
			List<Product> productList = productRepo.getAllProductByPRI(PRI);
			return productList;
		}
		return null;
	
	}

}
