package com.cassandra.repo;

import java.util.List;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import com.cassandra.entity.Product;
import com.cassandra.service.HarvesterRequest;
import com.cassandra.service.HarvesterResponse;

@Repository
public interface ProductRepo extends CassandraRepository<Product, Integer> {
	@Query("select * from harvester_platform.harvest_item where primary_request_id = ?1 ;")
	 List<Product> getAllProductByPRI(String PRI);
	
	HarvesterResponse getPRIForOneKeyword(HarvesterRequest request);
}
