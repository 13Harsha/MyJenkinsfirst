package com.cassandra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cassandra.entity.Product;
import com.cassandra.service.CassandraService;

@RestController
@RequestMapping("/cassandra")
public class CassandraController {

@Autowired
CassandraService cassandraService;	

@GetMapping("/getproductsbypri")
public List<Product> getProductsByPrimariRequestId(String pri){
	List<Product> productList = null;
	try {
		if(pri != null) {
		        productList = cassandraService.getProductsByPRI(pri);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return productList;
}

}
