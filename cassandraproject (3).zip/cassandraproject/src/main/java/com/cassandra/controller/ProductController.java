package com.cassandra.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cassandra.entity.Product;
import com.cassandra.service.CassandraDbProductService;
import com.cassandra.service.HarvesterRequest;
import com.cassandra.service.HarvesterResponse;
import com.cassandra.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@Autowired
	CassandraDbProductService cassandraDbProductService;
	
	HarvesterResponse response;
	
	@GetMapping("/getpri")
	public HarvesterResponse getPRIForOneKeyword(HarvesterRequest request) {
		try {
			if(request != null) {
			     response = productService.getPRIForOneDomainAndOneKeyword(request);
			}
			return response;
		}catch (Exception e) {
		    response.setMessage("excepton occured, unable to get PRI");
		    response.setStatusCode("000000");
		    return response;
		}
		
	}
	
	@GetMapping("/getproductsbyid")
	public List<Product> getAllProductByPrimaryRequestID(String primary_request_ID)	{
		try {
			if(primary_request_ID != null) {
				List<Product> productList = cassandraDbProductService.getProductsByPRI(primary_request_ID);
				return productList;
			}
			
		}catch (Exception e) {
			System.out.println("unable to get productList, Exception Occured");
			e.printStackTrace();
		}
		return null;
	}
}
